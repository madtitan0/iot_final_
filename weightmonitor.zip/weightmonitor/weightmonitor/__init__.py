"""
Package for weightmonitor.
"""
